package morpion;


/**
 *
 * Classe permettant de gérer les règles du jeu de <b>Morpion</b>, Il n'a aucun élément graphique
 *
 * @author J.-C. BOISSON 
 * @version 2.0
 *
 */
public class GestionnaireDesRegles
{
    /** Description textuelle de l'état de la grille*/
    private final State[][] values;

    /** Indique quel état a été dernièrement ajouté */
    private State lastPlayer;
   
    /** Indique qui a gagné */
    private final javafx.beans.property.ObjectProperty<State> gagnant;
        
    /** Indique si la partie a déjà été detecté comme finie */
    private final javafx.beans.property.BooleanProperty finished;
    
    /**
     * Constructeur d'un objet Gestionnaire de regles
     */
    public GestionnaireDesRegles()
    {
	values=new State[3][3];
        finished=new javafx.beans.property.SimpleBooleanProperty();
	gagnant=new javafx.beans.property.SimpleObjectProperty<State>();
        initialization();
    }

    /**
     * Procédure qui permet de réinitialiser les états du jeu
     */
    public final void initialization()
    {
	lastPlayer=State.VIDE;
	
	finished.setValue(Boolean.FALSE);
        gagnant.setValue(State.VIDE);
        
	for(int i=0;i<3;i++)
	    {
		for(int j=0;j<3;j++)
		    {
			values[i][j]=State.VIDE;
		    }
	    }
    }

    /**
     * Procédure qui permet d'indiquer quel coup a été joué
     *
     * @param line Ligne concernée
     * @param column Colonne concernée
     * @param symbol Symbole concerné et par effet de bord le joueur concerné
     */
    public void coupJoue(int line, int column, State symbol)
    {
	if(finished.getValue())
	    {
		System.out.println("Game already finished");
		System.out.println("Call init to reinitialise the game");
		return;
	    }

	if(values[line][column] != State.VIDE)
	    {
		System.out.println("Case "+line+" "+column+" already played.");
		System.out.println("No modification");
		return;
	    }

	lastPlayer=symbol;
	values[line][column]=lastPlayer;

	if(values[0][0]==values[0][1] && values[0][1]==values[0][2] && values[0][2]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }

	if( values[1][0]==values[1][1] && values[1][1]==values[1][2] && values[1][2]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }

	if( values[2][0]==values[2][1] && values[2][1]==values[2][2] && values[2][2]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }
	
	if(values[0][0]==values[1][0] && values[1][0]==values[2][0] && values[2][0]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }
	
	if( values[0][1]==values[1][1] && values[1][1]==values[2][1] && values[2][1]==lastPlayer)
	    {
                finished.setValue(Boolean.TRUE);
	    }

	if( values[0][2]==values[1][2] && values[1][2]==values[2][2] && values[2][2]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }

	if( values[0][0]==values[1][1] && values[1][1]==values[2][2] && values[2][2]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }

	if ( values[2][0]==values[1][1] && values[1][1]==values[0][2] && values[0][2]==lastPlayer )
	    {
		finished.setValue(Boolean.TRUE);
	    }
        
        if(finished.getValue())
        {
            gagnant.setValue(lastPlayer);
        }
    }
    
    /**
     * Fonction qui donne accès à la propriété correspondante en lecture seule
     *
     * @return La propriété demandée
     */
    public javafx.beans.property.ReadOnlyBooleanProperty getFinishedProperty()
    {
	return finished;
    }
    
    /**
     * Fonction qui donne accès à la propriété correspondante en lecture seule
     *
     * @return La propriété demandée
     */
    public javafx.beans.property.ReadOnlyObjectProperty<State> getGagnantProperty()
    {
	return gagnant;
    }

}

