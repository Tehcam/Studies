package morpion;
/**
 * Enumeration pour gérer l'état des cases : vide, avec un X ou avec un O
 */
public enum State
{
    /** Etat vide*/
    VIDE,
    /** Etat X */
    X,
    /** Etat X */
    O
};    
