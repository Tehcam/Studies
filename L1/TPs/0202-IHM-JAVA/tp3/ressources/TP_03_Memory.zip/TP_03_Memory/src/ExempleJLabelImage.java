import javax.swing.JFrame;
import javax.swing.JLabel;

public class ExempleJLabelImage extends JFrame
{
    public ExempleJLabelImage()
    {
	// cette instruction n'est pas utile mais on
	// l'a met pour ne pas oublier qu'il faudrait la mettre en cas
	// de constructeur non vide dans la classe mere
	super();

	JLabel component = new JLabelImage();
	
	getContentPane().add(component);
	
	setSize(400,200);
	setLocationRelativeTo(null);
	setTitle("Exemple de "+component.getClass().getName());
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setVisible(true);
    }

    public static void main(String[] args)
    {
	new ExempleJLabelImage();
    }
}
