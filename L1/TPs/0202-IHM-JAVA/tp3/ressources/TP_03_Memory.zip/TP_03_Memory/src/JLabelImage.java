import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.Color;

public class JLabelImage extends JLabel
{
    public JLabelImage()
    {
	// cette instruction n'est pas utile mais on
        // l'a met pour ne pas oublier qu'il faudrait la mettre en cas
        // de constructeur non vide dans la classe mere
        super();
	
	setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }

}
