/**
 * Classe Pokemon
 * @author Jessica Jonquet
 * @version 25/03/2019
 */
import java.io.*;
import java.util.Scanner;
public class Pokemon{
	public static void main (String[] args){

		DataInputStream clavier = new DataInputStream(System.in);

		int deux = 0;
		System.out.println("Entrez un nombre...");
		deux = clavier.readInt();
		System.out.println(deux);

		FileOutputStream f = new FileOutputStream("toto.txt");

		f.write(deux);
		f.write(2000);
		f.close();

		int[] u = new int[1];
		u[2] = 33;
		u = new int[7];
		u[7] = 99/deux;
	}
}